//
//  AppCollectionVC.swift
//  neonsdk
//
//  Created by Mustafa Kemal ARDA on 26.02.2024.
//

import UIKit
import NeonSDK

class AppCollectionVC: NeonCollectionViewCell<AppModel> {
    static let identifier = "AppCollectionVC"
    
    let imageView: UIImageView = {
       let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.image = UIImage(systemName: "questionmark")
        imageView.layer.cornerRadius = 10
        imageView.clipsToBounds = true
        return imageView
    }()
    
    let appLabel: UILabel = {
       let label = UILabel()
        label.numberOfLines = 0
        label.font = .systemFont(ofSize: 18, weight: .regular)
        label.textAlignment = .center
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }

    override func configure(with app: AppModel) {
        super.configure(with: app)
        imageView.image = app.appLogo
        appLabel.text = app.appName
    }
    

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupUI() {
        self.addSubview(imageView)
        self.addSubview(appLabel)
        self.layer.borderWidth = 1.5
        self.layer.cornerRadius = 10
        imageView.snp.makeConstraints { make in
            make.top.equalTo(self.snp.top)
            make.left.equalTo(self.snp.left)
            make.right.equalTo(self.snp.right)
            make.height.equalTo(self.frame.size.height - 30)
            make.width.equalTo(self.frame.size.width)
        }
        
        appLabel.snp.makeConstraints { make in
            make.top.equalTo(imageView.snp.bottom)
            make.centerX.equalTo(self.snp.centerX)
            make.bottom.equalTo(self.snp.bottom)
            make.height.equalTo(30)
            make.width.equalTo(self.frame.size.width)
        }
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        self.imageView.image = nil
    }
}
