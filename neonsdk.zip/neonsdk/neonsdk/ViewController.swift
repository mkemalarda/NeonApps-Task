//
//  ViewController.swift
//  neonsdk
//
//  Created by Oğuzhan Akın on 26.02.2024.
//

import UIKit
import NeonSDK

class ViewController: UIViewController {
    
    var apps: [AppModel] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        view.backgroundColor = .systemMint
        
        let app1 = AppModel(appName: "AI Rap & Music Generator", appLogo: UIImage(named: "airap"), appURL: "https://apps.apple.com/tr/app/ai-voice-music-generator/id6447696368?l=tr", releaseDate: "May 8, 2023", category: .music)
        let app2 = AppModel(appName: "Smart Cleaner", appLogo: UIImage(named: "cleaner"), appURL: "https://apps.apple.com/us/app/smart-cleaner-free-up-space/id1576477935", releaseDate: "Oct 18, 2021", category: .utilities)
        let app3 = AppModel(appName: "PDF Editor", appLogo: UIImage(named: "editor"), appURL: "https://apps.apple.com/tr/app/pdf-converter-reader-editor/id1623317186", releaseDate: "Sep 11, 2022", category: .productivity)
        let app4 = AppModel(appName: "AI Art Creator", appLogo: UIImage(named: "aiimage"), appURL: "https://apps.apple.com/tr/app/ai-art-generator-avatar/id6443530742", releaseDate: "Oct 8, 2022", category: .graphics_design)
        let app5 = AppModel(appName: "AI Rap & Music Generator", appLogo: UIImage(named: "airap"), appURL: "https://apps.apple.com/tr/app/ai-voice-music-generator/id6447696368?l=tr", releaseDate: "May 8, 2023", category: .music)
        let app6 = AppModel(appName: "Smart Cleaner", appLogo: UIImage(named: "cleaner"), appURL: "https://apps.apple.com/us/app/smart-cleaner-free-up-space/id1576477935", releaseDate: "Oct 18, 2021", category: .utilities)
        let app7 = AppModel(appName: "PDF Editor", appLogo: UIImage(named: "editor"), appURL: "https://apps.apple.com/tr/app/pdf-converter-reader-editor/id1623317186", releaseDate: "Sep 11, 2022", category: .productivity)
        let app8 = AppModel(appName: "AI Art Creator", appLogo: UIImage(named: "aiimage"), appURL: "https://apps.apple.com/tr/app/ai-art-generator-avatar/id6443530742", releaseDate: "Oct 8, 2022", category: .graphics_design)
        let app9 = AppModel(appName: "AI Rap & Music Generator", appLogo: UIImage(named: "airap"), appURL: "https://apps.apple.com/tr/app/ai-voice-music-generator/id6447696368?l=tr", releaseDate: "May 8, 2023", category: .music)
        let app10 = AppModel(appName: "Smart Cleaner", appLogo: UIImage(named: "cleaner"), appURL: "https://apps.apple.com/us/app/smart-cleaner-free-up-space/id1576477935", releaseDate: "Oct 18, 2021", category: .utilities)
        let app11 = AppModel(appName: "PDF Editor", appLogo: UIImage(named: "editor"), appURL: "https://apps.apple.com/tr/app/pdf-converter-reader-editor/id1623317186", releaseDate: "Sep 11, 2022", category: .productivity)
        let app12 = AppModel(appName: "AI Art Creator", appLogo: UIImage(named: "aiimage"), appURL: "https://apps.apple.com/tr/app/ai-art-generator-avatar/id6443530742", releaseDate: "Oct 8, 2022", category: .graphics_design)
        
        apps = [app1, app2, app3, app4, app5, app6, app7, app8, app9, app10, app11, app12]
        
        createUI()
    }
    
    private func createUI() {
        let collectionView = NeonCollectionView<AppModel, AppCollectionVC>(
            objects: apps,
            itemsPerRow: 1,
            leftPadding: 50,
            rightPadding: 50,
            horizontalItemSpacing: 0,
            verticalItemSpacing: 20,
            heightForItem: 150)
        
        view.addSubview(collectionView)
        collectionView.snp.makeConstraints { make in
            make.top.bottom.left.right.equalToSuperview()
        }
        
        collectionView.didSelect = { object, indexPath in
            let vc = DetailVC()
            vc.selectedApp = self.apps[indexPath.row]
           //self.navigationController?.pushViewController(vc, animated: true)
            
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true)
        }
        
        collectionView.contextMenuActions = [
            ContextMenuAction(title: "Delete", imageSystemName: "trash", isDestructive: true, action: { app, indexPath in
                //
            }),
            
            ContextMenuAction(title: "Edit", imageSystemName: "pencil", isDestructive: false, action: { app, indexPath in
                print("Edit action for app: \(self.apps[indexPath.row].appName)")
            })
        ]
    }
    
    
}
