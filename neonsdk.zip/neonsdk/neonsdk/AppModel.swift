//
//  AppModel.swift
//  neonsdk
//
//  Created by Mustafa Kemal ARDA on 26.02.2024.
//

import Foundation
import UIKit

enum AppCategory: String {
    case music = "Music", utilities = "Utilities", productivity = "Productivity", graphics_design = "Graphics & Design"
}

struct AppModel {
    var appName: String
    var appLogo: UIImage?
    var appURL: String
    var releaseDate: String
    var category: AppCategory
}
