//
//  ViewController.swift
//  taskNeonSDK
//
//  Created by Mustafa Kemal ARDA on 27.02.2024.
//

import UIKit
import NeonSDK


class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .systemBackground
        
        createUI()
        
    }
    
    func createUI(){
        
        let testimonialView = NeonTestimonialView()
            view.addSubview(testimonialView)
            testimonialView.snp.makeConstraints { make in
                make.left.right.equalToSuperview()
                make.top.equalToSuperview().offset(70)
                make.height.equalTo(220)
            }
        
        testimonialView.testimonialTextColor = .black
        testimonialView.testimonialbackgroundColor = .white
        testimonialView.currentTestimonialPageTintColor = .systemBlue
        testimonialView.testimonialPageTintColor = .darkGray
        testimonialView.testimonialbackgroundCornerRadious = 12
        testimonialView.pageControlType = .V1
        
        testimonialView.addTestimonial(title: "Great App!", testimonial: "So, I decided to clean my phone with this app. I was able to get rid of so many useless photos and videos so easily! This app is amazing.", author: "Rui Gomes")
        testimonialView.addTestimonial(title: "Amazing!", testimonial: "So, I decided to clean my phone with this app. I was able to get rid of so many useless photos and videos so easily! This app is amazing.", author: "Muoyo Okame")
        testimonialView.addTestimonial(title: "Love it!", testimonial: "So, I decided to clean my phone with this app. I was able to get rid of so many useless photos and videos so easily! This app is amazing.", author: "Kaveh Vaziri")
        
        testimonialView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.top.equalToSuperview().offset(70)
            make.height.equalTo(220)
        }
    }

}

