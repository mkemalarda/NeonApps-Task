//
//  BouncingVC.swift
//  taskNeonSDK
//
//  Created by Mustafa Kemal ARDA on 27.02.2024.
//

import UIKit
import NeonSDK

class BouncingVC: UIViewController {


    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .systemBackground
        
        let btnBuy = NeonBouncingButton()
        view.addSubview(btnBuy)
        btnBuy.setTitle("Button", for: .normal)
        btnBuy.backgroundColor = .systemBlue
        btnBuy.layer.cornerRadius = 15
        btnBuy.addTarget(self, action: #selector(clickedButton), for: .touchUpInside)
        btnBuy.snp.makeConstraints { make in
            make.width.equalTo(100)
            make.center.equalToSuperview()
            btnBuy.bouncingDuration = 0.8
            btnBuy.bouncingScale = 1.15
        }
        
    }
    @objc func clickedButton(){
        print("clicked")
    }
}

