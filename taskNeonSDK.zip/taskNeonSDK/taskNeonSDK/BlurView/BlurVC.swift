//
//  BlurVC.swift
//  taskNeonSDK
//
//  Created by Mustafa Kemal ARDA on 27.02.2024.
//

import UIKit
import NeonSDK
final class BlurVC: UIViewController {
    
  var blurView: NeonBlurView!
  var changeBlueView: UIButton!
    
  override func viewDidLoad() {
    super.viewDidLoad()
    view.backgroundColor = .white
    createUI()
  }
  private func createUI() {
    blurView = NeonBlurView()
    blurView.colorTint = .black
    blurView.colorTintAlpha = 0.2
    blurView.blurRadius = 10
    blurView.scale = 1
    view.addSubview(blurView)
    blurView.snp.makeConstraints { make in
      make.center.equalToSuperview()
      make.height.width.equalTo(200)
    }
    changeBlueView = UIButton()
    changeBlueView.setTitle("Change", for: .normal)
    changeBlueView.layer.cornerRadius = 8
    changeBlueView.backgroundColor = .orange
    view.addSubview(changeBlueView)
    changeBlueView.snp.makeConstraints { make in
      make.centerX.equalToSuperview()
      make.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(20)
      make.height.width.equalTo(100)
    }
    changeBlueView.addTarget(self, action: #selector(changeView), for: .touchUpInside)
  }
  @objc private func changeView() {
    blurView.colorTint = .black
    blurView.colorTintAlpha = 0.1
    blurView.blurRadius = 2
    blurView.scale = 1.5
  }
}
