//
//  PageVC.swift
//  taskNeonSDK
//
//  Created by Mustafa Kemal ARDA on 27.02.2024.
//

import UIKit
import NeonSDK

class PageVC: UIViewController, NeonBasePageControlDelegate {
    
    let pageControl = NeonPageControlV1()
    var index = 0
    
    var imageView = UIImageView()
    
    private var titles: [String] = ["Page 1", "Page 2", "Page 3"]
    
    private var subtitles: [String] = ["Palace", "Another Palace", "Unknown Knight"]
        
    lazy var button: UIButton = {
        let button = UIButton()
        button.setTitle("Next Page", for: .normal)
        button.backgroundColor = .systemBlue
        button.addAction {
            print("Index 1: \(self.index)")
            if self.index >= 2 {
                
                self.index = 0
                print("Index 2: \(self.index)")
            }
            
            else {
                self.index += 1
                print("Index 3: \(self.index)")
            }
            
            print("Index 4: \(self.index)")
            
            self.pageControl.set(progress: self.index, animated: true)
            
        }
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .systemBackground

        
        button.layer.cornerRadius = 10
        view.addSubview(button)
        
        
        imageView.image = UIImage(named: "kingdom1")
        view.addSubview(imageView)
        
        imageView.snp.makeConstraints { make in
            make.center.equalToSuperview()
            make.width.equalToSuperview().multipliedBy(0.7)
            make.height.equalToSuperview().multipliedBy(0.3)
        }
        
        button.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).inset(30)
            make.height.equalTo(60)
            make.width.equalTo(170)
        }
        
        button.addAction {
            switch self.index {
            case 0:
                
                self.imageView.image = UIImage(named: "kingdom1")
            case 1:
                
                self.imageView.image = UIImage(named: "kingdom2")
            default:
                
                self.imageView.image = UIImage(named: "kingdom3")
            }
        }
        

       
        view.addSubview(pageControl)
        
        pageControl.delegate = self

        pageControl.numberOfPages = 3
        pageControl.radius = 3
        pageControl.currentPageTintColor = .systemBlue
        pageControl.tintColors = [UIColor.systemGray, UIColor.systemGray, UIColor.systemGray]
        pageControl.padding = 6
        pageControl.enableTouchEvents = true
        pageControl.snp.makeConstraints { make in
            make.bottom.equalTo(view.snp.bottom).inset(45)
            make.centerX.equalToSuperview()
        }
        
        
    }
    
    func didTouch(pager: NeonSDK.NeonBasePageControl, index: Int) {
        print("clicked \(index)")
    }
}

