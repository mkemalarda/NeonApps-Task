//
//  AppDelegate.swift
//  taskNeonSDK
//
//  Created by Mustafa Kemal ARDA on 27.02.2024.
//

import UIKit
import NeonSDK

@main
class AppDelegate: UIResponder, UIApplicationDelegate {


    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        Font.configureFonts(font: .Inter)
        Neon.configure(window: &window, onboardingVC: BouncingVC(), paywallVC: ViewController(), homeVC: ViewController())
        
        
        return true
    }

   


}

